package battleships;

public class ShipException extends Exception {

    public ShipException() {
        super();
    }


    public ShipException(String message) {
        super(message);
    }
}
