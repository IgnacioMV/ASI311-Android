package com.excilys.formation.battleships.android.ui.ships;

public interface DrawableShip {
    int getDrawable();
}
